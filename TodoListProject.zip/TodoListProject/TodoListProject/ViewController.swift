//
//  ViewController.swift
//  TodoList
//
//  Created by Thanh Quan on 2020-03-12.
//  Copyright © 2020 Thanh Quan. All rights reserved.
//

import UIKit

class Todo{
    var title: String?
    var detail: String?
    var time: Date?
    init(title: String, detail: String, time: Date){
        self.title = title
        self.detail = detail
        self.time = time
    }
}

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var todoList: UITableView!
    @IBOutlet weak var num_events: UILabel!
    
  
    
    var todoArray = [Todo]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        let action1 = Todo(title: "Finish Homework", detail: "Finish Homework Detail", time: Date())
        todoArray.append(action1)
        let action2 = Todo(title: "Go to gym", detail: "Go to gym Detail", time: Date())
        todoArray.append(action2)
        let action3 = Todo(title: "Finish Homework", detail: "Finish Homework Detail", time: Date())
        todoArray.append(action3)
        let action4 = Todo(title: "Finish Homework", detail: "Finish Homework Detail", time: Date())
        todoArray.append(action4)
        let action5 = Todo(title: "Finish Homework", detail: "Finish Homework Detail", time: Date())
        todoArray.append(action5)
        num_events.text = String(todoArray.count)
        print(todoArray.count)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //VIEW TABLE
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (todoArray.count);
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "cell");
        cell.textLabel?.text = todoArray[indexPath.row].title
        
        return cell;
    }
    
    //SELECT CELL
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let todo = todoArray[indexPath.row]
        performSegue(withIdentifier: "showdetail", sender: todo)
    }
    //PASS DATA
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showdetail"{
            let destinationViewController = segue.destination as! DetailViewController
            destinationViewController.todo = sender as? Todo
        }
    }
    //DELETE DATA
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let  delete = UIContextualAction(style: .destructive, title: "Delete")
        { (contextualAction, view, actionPerformed: (Bool) ->()) in
            self.todoArray.remove(at: indexPath.row)
            self.num_events.text = String(self.todoArray.count)
            tableView.reloadData()
        }
        return UISwipeActionsConfiguration(actions: [delete])
    }

    
    
    
    //ADD FUNCTION
    @IBAction func AddEvent(_ sender: Any) {
        alertForm()
    }

    //add alert
    func alertForm() {

        let alertController = UIAlertController(title: "Enter your event", message: "", preferredStyle: .alert)

        let confirmAction = UIAlertAction(title: "Enter", style: .default) { (_) in

            let title = alertController.textFields?[0].text
            let detail = alertController.textFields?[0].text
            let action6 = Todo(title: title!, detail: detail!, time: Date())
            self.todoArray.append(action6)
            let indexPath = IndexPath(row: self.todoArray.count-1, section: 0)
            self.todoList.beginUpdates()
            self.todoList.insertRows(at: [indexPath], with: .automatic)
            self.todoList.endUpdates()
            self.view.endEditing(true)

        }



        alertController.addTextField { (textField) in
            textField.placeholder = "Enter Event"
        }
        alertController.addTextField { (textField) in
            textField.placeholder = "Enter DESCRIPTION"
        }


        alertController.addAction(confirmAction)

        self.present(alertController, animated: true, completion: nil)

    }
}


